<?php
include_once 'include/util.inc';

// This is the "home page", which redirects to the index controller to the get_index() function
redirect("index");
